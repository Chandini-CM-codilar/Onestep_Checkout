require(['jquery'], function($) {
    jQuery(window).load(function() {
        alert("test");
        setTimeout(function(){
            jQuery('.checkout-shipping-method .actions-toolbar .action.primary').trigger('click');
            jQuery('form#co-payment-form').show();
        }, 5000);
    });
});
